<?php

class Wp_Ajax_Login_Front_Action {

	private $plugin_name;
	private $version;
	
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	public function enqueue_styles() {
		
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-ajax-login-front.css', array(), $this->version, 'all' );
	}
	
	public function enqueue_scripts() {
		
		wp_enqueue_script( 'bootstrap', plugin_dir_url( __FILE__ ) . 'js/bootstrap.js', array( 'jquery' ), '3.3.4', true );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-ajax-login-front.js', array( 'jquery' ), $this->version, true );
		
		wp_localize_script( $this->plugin_name, 'lrajax', array( 
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		));

	}


	// LOGIN
	public function lr_login_form(){

  		// Get variables
		$user_login				= $_POST['lr_user_login'];	
		$user_pass				= $_POST['lr_user_pass'];

		// Check CSRF token
		if( !check_ajax_referer( 'ajax-login-nonce', 'login-form', false) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Session token has expired, please reload the page and try again', 'wp-ajax-login').'</div>'));
		}
	 	
	 	// Check if input variables are empty
	 	elseif( empty($user_login) || empty($user_pass) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Please fill all form fields', 'wp-ajax-login').'</div>'));
	 	} else { // Now we can insert this account

	 		$user = wp_signon( array('user_login' => $user_login, 'user_password' => $user_pass), false );
			
		    if( is_wp_error($user) ){
				echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.$user->get_error_message().'</div>'));
			} else{
				echo json_encode(array('error' => false, 'message'=> '<div class="alert alert-success">'.__('Login successful, reloading page...', 'wp-ajax-login').'</div>'));
			}
	 	}

	 	die();
	}

	// REGISTER
	public function lr_register_form(){

  		// Get variables
		$user_login				= $_POST['lr_user_login'];	
		$user_email				= $_POST['lr_user_email'];
		
		
		// Check CSRF token
		if( !check_ajax_referer( 'ajax-login-nonce', 'register-form', false) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Session token has expired, please reload the page and try again', 'wp-ajax-login').'</div>'));
			die();
		}
	 	
	 	// Check if input variables are empty
	 	elseif( empty($user_login) || empty($user_email) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Please fill all form fields', 'wp-ajax-login').'</div>'));
			die();
	 	}
		
		$errors = register_new_user($user_login, $user_email);	
		
		if( is_wp_error($errors) ){

			$registration_error_messages = $errors->errors;

			$display_errors = '<div class="alert alert-danger">';
			
				foreach($registration_error_messages as $error){
					$display_errors .= '<p>'.$error[0].'</p>';
				}

			$display_errors .= '</div>';

			echo json_encode(array('error' => true, 'message' => $display_errors));

		} else {
			echo json_encode(array('error' => false, 'message' => '<div class="alert alert-success">'.__( 'Registration complete. Please check your e-mail.', 'wp-ajax-login').'</p>'));
		}
	 

	 	die();
	}

	// LOGIN
	public function lr_logout(){
		wp_logout();
		echo json_encode(array('error' => false, 'message'=> '<div class="alert alert-success">'.__('Logout successful, reloading page...', 'wp-ajax-login').'</div>'));
		die();
	}

	// RESET PASSWORD
	function lr_reset_password(){

		
  		// Get variables
		$username_or_email = $_POST['lr_user_or_email'];

		// Check CSRF token
		if( !check_ajax_referer( 'ajax-login-nonce', 'password-reset', false) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Session token has expired, please reload the page and try again', 'wp-ajax-login').'</div>'));
		}		

	 	// Check if input variables are empty
	 	elseif( empty($username_or_email) ){
			echo json_encode(array('error' => true, 'message'=> '<div class="alert alert-danger">'.__('Please fill all form fields', 'wp-ajax-login').'</div>'));
	 	} else {

			$username = is_email($username_or_email) ? sanitize_email($username_or_email) : sanitize_user($username_or_email);

			$user_forgotten = $this->lr_lostPassword_retrieve($username);
			
			if( is_wp_error($user_forgotten) ){
			
				$lostpass_error_messages = $user_forgotten->errors;

				$display_errors = '<div class="alert alert-warning">';
				foreach($lostpass_error_messages as $error){
					$display_errors .= '<p>'.$error[0].'</p>';
				}
				$display_errors .= '</div>';
				
				echo json_encode(array('error' => true, 'message' => $display_errors));
			}else{
				echo json_encode(array('error' => false, 'message' => '<p class="alert alert-success">'.__('Password Reset. Please check your email.', 'wp-ajax-login').'</p>'));
			}
	 	}

	 	die();
	}

	private function lr_lostPassword_retrieve( $user_input ) {
		
		global $wpdb, $wp_hasher;

		$errors = new WP_Error();

		if ( empty( $user_input ) ) {
			$errors->add('empty_username', __('<strong>ERROR</strong>: Enter a username or email address.', 'wp-ajax-login'));
		} elseif ( strpos( $user_input, '@' ) ) {
			$user_data = get_user_by( 'email', trim( $user_input ) );
			if ( empty( $user_data ) )
				$errors->add('invalid_email', __('<strong>ERROR</strong>: There is no user registered with that email address.', 'wp-ajax-login'));
		} else {
			$login = trim($user_input);
			$user_data = get_user_by('login', $login);
		}

		do_action( 'lostpassword_post', $errors );

		if ( $errors->get_error_code() )
			return $errors;

		if ( !$user_data ) {
			$errors->add('invalidcombo', __('<strong>ERROR</strong>: Invalid username or email.', 'wp-ajax-login'));
			return $errors;
		}

		// Redefining user_login ensures we return the right case in the email.
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		$key = get_password_reset_key( $user_data );

		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$message = __('Someone has requested a password reset for the following account:', 'wp-ajax-login') . "\r\n\r\n";
		$message .= network_home_url( '/' ) . "\r\n\r\n";
		$message .= sprintf(__('Username: %s', 'wp-ajax-login'), $user_login) . "\r\n\r\n";
		$message .= __('If this was a mistake, just ignore this email and nothing will happen.', 'wp-ajax-login') . "\r\n\r\n";
		$message .= __('To reset your password, visit the following address:', 'wp-ajax-login') . "\r\n\r\n";
		$message .= '<' . network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') . ">\r\n";
		
		if ( is_multisite() )
			$blogname = $GLOBALS['current_site']->site_name;
		else
			
			$blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);

		$title = sprintf( __('[%s] Password Reset', 'wp-ajax-login'), $blogname );
		
		$title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

		$message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );

		if ( $message && !wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) )
			$errors->add('mailfailed', __('<strong>ERROR</strong>: The email could not be sent.Possible reason: your host may have disabled the mail() function.', 'wp-ajax-login'));

		return true;
	}

}
