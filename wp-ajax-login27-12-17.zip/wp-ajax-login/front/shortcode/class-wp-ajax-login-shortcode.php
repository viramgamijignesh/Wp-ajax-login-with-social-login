<?php
//include_once plugin_dir_path(dirname(dirname(__FILE__))).'admin/class-wp-ajax-login-admin-action.php';
include (plugin_dir_path( __FILE__ ) . 'facebook-sdk/autoload.php');
//include (plugin_dir_path( __FILE__ ) . 'google-sdk/init.php');
global $wp, $wpdb, $lr_social_login;
use Facebook\Facebook;
use Facebook\Exceptions\FacebookSDKException;
use Facebook\Exceptions\FacebookResponseException;

$lr_social_login = get_option( 'lr_social_login' );

class Wp_Ajax_Login_Shortcode {

	private $app_id = '';
	private $app_secret = '';
	private $callback_url = '';
	private $access_token;
	private $redirect_url;
	private $facebook_details;
	
	public function __construct()
    {

        // We register our shortcode
        add_shortcode( 'lr_facebook', array($this, 'renderShortcode') );

        // Callback URL
        add_action( 'wp_ajax_lr_facebook', array($this, 'apiCallback' ) );
        add_action( 'wp_ajax_nopriv_lr_facebook', array($this, 'apiCallback' ) );
		add_action( 'wp_footer', array($this, 'lr_login_register_modal' ) );		
		

    }
	function lr_login_register_modal() { 
	?>

		<div class="modal fade pt-user-modal" id="pt-user-modal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog" data-active-tab="">
			
				<div class="modal-content" style="background-color :#<?php $lr_general=get_option('lr_general'); echo $lr_general['form_background_color']; ?>">
				
				<?php 
					if( ! is_user_logged_in() ){ // only show the registration/login form to non-logged-in members ?>	
						<div class="modal-body">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color :#<?php echo $lr_general['font_color_callback']; ?>">&times;</span></button>
							
							<!-- Register form -->
							<div class="pt-register">
								<?php $lr_signup=get_option('lr_signup');?>
								<div class="header_text">
								<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
								<?php if($lr_signup['signup_header_text'] ){ 
										echo $lr_signup['signup_header_text']; ?>
									<?php }else{ printf( __('Join %s', 'wp-ajax-login'), get_bloginfo('name') ); } ?>
								</h3>
								</div>
								<div class="logo">
									<?php $logo_image = $lr_general['logo_image']; ?>
									<img id='' src='<?php echo $logo_image; ?>'>
								</div>
								<hr>

								<?php if( $lr_signup ){ ?>
										
										<form id="pt_registration_form" action="<?php echo home_url( '/' ); ?>" method="POST">
										
										
										<?php if($lr_signup['signup_first_name'] ){ ?>
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('First Name', 'wp-ajax-login'); ?></span>
												<input class="form-control input-lg required" name="lr_first_name" type="text"  placeholder="<?php _e('First Name', 'wp-ajax-login'); ?>" required />
											</div>										
										<?php } ?>	
										
										<?php if($lr_signup['signup_last_name'] ){ ?>
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Last Name', 'wp-ajax-login'); ?></span>
												<input class="form-control input-lg required" name="lr_last_name" type="text" placeholder="<?php _e('Last Name', 'wp-ajax-login'); ?>" required />
											</div>
										<?php } ?>		
											
											
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Username', 'wp-ajax-login'); ?></span>
												<input class="form-control input-lg required" name="lr_user_login" type="text" placeholder="<?php _e('Username', 'wp-ajax-login'); ?>" />
											</div>
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Email', 'wp-ajax-login'); ?></span>
												<input class="form-control input-lg required" name="lr_user_email" id="pt_user_email" type="email" placeholder="<?php _e('Email', 'wp-ajax-login'); ?>" />
											</div>									
											
											
											<div class="form-field">
												<input type="hidden" name="action" value="lr_register_form"/>
												<?php $lr_general=get_option('lr_general');?>	
												<button class="btn btn-theme btn-lg" style="color :#<?php echo $lr_general['font_color_callback']; ?>" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
												<?php if($lr_signup['signup_button_text'] ){ ?>
												<?php echo $lr_signup['signup_button_text']; ?>
												<?php }else{ _e('Sign up', 'wp-ajax-login'); } ?></button>
											</div>
											<?php wp_nonce_field( 'ajax-login-nonce', 'register-form' ); ?>
										</form>
										<div class="pt-errors"></div>

								<?php } else {

									echo '<div class="alert alert-warning">'.__('Registration is disabled.', 'wp-ajax-login').'</div>';

								} ?>

								</div>

									<!-- Login form -->
									<div class="pt-login">
								
									<?php $lr_login=get_option('lr_login');?>								
									<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
									
									<?php $logo_image = $lr_general['logo_image'];
									if($logo_image !=''){
									?>
									<div class="logo">									
										<img id='' src='<?php echo $logo_image; ?>'>
									</div>
									<?php } ?>
									<?php if($lr_login['login_header_text'] ){ 
											echo $lr_login['login_header_text']; ?>
									<?php }else{ printf( __('Login to %s', 'wp-ajax-login'), get_bloginfo('name') ); } ?>
									
									</h3>
										<hr>
								 
										<form id="pt_login_form" action="<?php echo home_url( '/' ); ?>" method="post">
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Username', 'wp-ajax-login') ?></span>
												<input class="form-control input-lg required" name="lr_user_login" type="text" placeholder="<?php _e('Username', 'wp-ajax-login') ?>" />
											</div>
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Password', 'wp-ajax-login')?></span>
												<input class="form-control input-lg required" name="lr_user_pass" id="pt_user_pass" type="password"/ placeholder="<?php _e('Password', 'wp-ajax-login')?>">
											</div>
											<div class="form-field">
												<input type="hidden" name="action" value="lr_login_form"/>
												<button class="btn btn-theme btn-lg" style="color :#<?php echo $lr_general['font_color_callback']; ?>" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
												<?php if($lr_login['login_button_text'] ){ 
													echo $lr_login['login_button_text']; ?>
												<?php }else{ _e('Login', 'wp-ajax-login'); } ?>
												
												</button> <a class="alignright" href="#pt-reset-password" style="color:#<?php echo $lr_general['font_color_callback'];?>"><?php _e('Lost Password?', 'wp-ajax-login') ?></a>
											</div>
											<?php wp_nonce_field( 'ajax-login-nonce', 'login-form' ); ?>
										</form>
										<div class="pt-errors"></div>
									</div>
									
									<!-- Lost Password form -->
									<div class="pt-reset-password">
									<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
									<?php $lr_fpsw=get_option('lr_fpsw');?>
									<?php if($lr_fpsw['fpsw_header_text'] ){ 
											echo $lr_fpsw['fpsw_header_text']; ?>
									<?php }else {_e('Reset Password', 'wp-ajax-login'); } ?>
									</h3>
										<p style="color :#<?php echo $lr_general['font_color_callback']; ?>">
										<?php if($lr_fpsw['fpsw_header_detail_text'] ){ 
											echo $lr_fpsw['fpsw_header_detail_text']; ?>
										<?php }else {_e( 'Enter the username or e-mail you used in your profile. A password reset link will be sent to you by email.', 'wp-ajax-login'); } ?></p>
										<hr>
								 
										<form id="pt_reset_password_form" action="<?php echo home_url( '/' ); ?>" method="post">
											<div class="form-field">
												<span class="screen-reader-text"><?php _e('Username or E-mail', 'wp-ajax-login') ?></span>
												<input class="form-control input-lg required" name="lr_user_or_email" id="pt_user_or_email" type="text" placeholder="<?php _e('Username or E-mail', 'wp-ajax-login') ?>" />
											</div>
											<div class="form-field">
												<input type="hidden" name="action" value="lr_reset_password"/>
												<button class="btn btn-theme btn-lg" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
												<?php if($lr_fpsw['fpsw_button_text'] ){ 
													echo $lr_fpsw['fpsw_button_text']; ?>
												<?php }else { _e('Get new password', 'wp-ajax-login'); } ?></button>
											</div>
											<?php wp_nonce_field( 'ajax-login-nonce', 'password-reset' ); ?>
										</form>
										<div class="pt-errors"></div>
									</div>

									<div class="pt-loading">
										<p><i class="fa fa-refresh fa-spin"></i><br><?php _e('Loading...', 'wp-ajax-login') ?></p>
									</div>
									<?php 
										if(!session_id()) {
											session_start();
										}

										// No need for the button is the user is already logged
										if(is_user_logged_in())
											return;

										// We save the URL for the redirection:
										if(!isset($_SESSION['lr_facebook_url']))
											$_SESSION['lr_facebook_url'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
										if (get_option( 'users_can_register' )) {
											$button_label = __('Login or Register with Facebook', 'lrweb');
										} else {
											$button_label = __('Login with Facebook', 'lrweb');
										}

										
										$facebook_url = $this->getLoginUrl();										
										
									?>
									<a target="_blank" href="<?php echo $facebook_url; ?>" class="btn" id="lr-facebook-button">Facebook</a>
									<div class="fb-login-button" data-max-rows="1" data-size="small" data-button-type="login_with" data-show-faces="false" data-auto-logout-link="false" data-use-continue-as="false"></div>
									<a target="_blank" href="<?php echo $google_url; ?>" class="btn" id="lr-google-button">Google</a>
						</div>
						<div class="modal-footer">
							<span class="pt-register-footer" style="color :#<?php echo $lr_general['font_color_callback']; ?>">
								<?php if($lr_login['login_footer_text'] ){ 
										echo $lr_login['login_footer_text']; ?>
								<?php }else{ _e('Don\'t have an account?', 'wp-ajax-login');}?>
								<a href="#pt-register" style="color:#<?php echo $lr_general['font_color_callback']; ?>"><?php _e('Sign Up', 'wp-ajax-login'); ?></a>
							</span>
								
							<span class="pt-login-footer" style="color :#<?php echo $lr_general['font_color_callback']; ?>">
								
								<?php if($lr_signup['signup_footer_text'] ){
										echo $lr_signup['signup_footer_text']; ?>
								<?php }else{ _e('Already have an account?', 'wp-ajax-login'); } ?> <a href="#pt-login" style="color:#<?php echo $lr_general['font_color_callback']; ?>"><?php _e('Login', 'wp-ajax-login'); ?></a>
							</span>
						</div>
					<?php } else { ?>
						<div class="modal-body">
							<div class="pt-logout">							
								<div class="alert alert-info"><?php $current_user = wp_get_current_user(); printf( __( 'You have already logged in as %1$s. <a href="#logout">Logout?</a>', 'wp-ajax-login' ), $current_user->user_login );?></div>
								<div class="pt-errors"></div>
							</div>
						</div>
					<?php } ?>		
					</div>
				</div>
			</div>
	<?php }
	public function renderShortcode() {

        // Start the session
        if(!session_id()) {
            session_start();
        }

        // No need for the button is the user is already logged
        if(is_user_logged_in())
            return;

        // We save the URL for the redirection:
        if(!isset($_SESSION['lr_facebook_url']))
            $_SESSION['lr_facebook_url'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

        // Different labels according to whether the user is allowed to register or not
        if (get_option( 'users_can_register' )) {
            $button_label = __('Login or Register with Facebook', 'lrweb');
        } else {
            $button_label = __('Login with Facebook', 'lrweb');
        }

        // HTML markup
        $html = '<div id="lr-facebook-wrapper">';

        // Messages
        if(isset($_SESSION['lr_facebook_message'])) {
            $message = $_SESSION['lr_facebook_message'];
            $html .= '<div id="lr-facebook-message" class="alert alert-danger">'.$message.'</div>';
            // We remove them from the session
            unset($_SESSION['lr_facebook_message']);
        }

        // Button
        $html .= '<a href="#pt-login" class="btn" id="lr-facebook-button">'.$button_label.'</a>';

        $html .= '</div>';
		
        // Write it down
        return $html;

    }
	public function initApi() {
		$lr_social_login = get_option( 'lr_social_login' );
		$app_id = $lr_social_login['fb_applcation_id'];
		$app_secret = $lr_social_login['fb_applcation_secret'];		
		
        $facebook = new Facebook([
            'app_id' => $app_id,
            'app_secret' => $app_secret,
            'default_graph_version' => 'v2.2',
            'persistent_data_handler' => 'session'
        ]);
		// echo '<pre>';
		// print_r($facebook);
        return $facebook;

    }
	public function getLoginUrl() {

        if(!session_id()) {
            session_start();
        }

        $fb = $this->initApi();

        $helper = $fb->getRedirectLoginHelper();

        // Optional permissions
        $permissions = ['email'];
		$lr_social_login = get_option( 'lr_social_login' );
		$callback_url = $lr_social_login['fb_callback_url'];
        $url = $helper->getLoginUrl($callback_url, $permissions);
		
        return esc_url($url);

    }
	public function apiCallback() {

        if(!session_id()) {
            session_start();
        }

        // Set the Redirect URL:
        $this->redirect_url = (isset($_SESSION['lr_facebook_url'])) ? $_SESSION['lr_facebook_url'] : home_url();

        // We start the connection
        $fb = $this->initApi();

        // We save the token in our instance
        $this->access_token = $this->getToken($fb);

        // We get the user details
        $this->facebook_details = $this->getUserDetails($fb);

        // We first try to login the user
        $this->loginUser();

        // Otherwise, we create a new account
        $this->createUser();

        // Redirect the user
        header("Location: ".$this->redirect_url, true);
        die();

    }
	public function getToken($fb) {

        // Assign the Session variable for Facebook
        $_SESSION['FBRLH_state'] = $_GET['state'];

        // Load the Facebook SDK helper
        $helper = $fb->getRedirectLoginHelper();

        // Try to get an access token
        try {
            $accessToken = $helper->getAccessToken();
        }
        // When Graph returns an error
        catch(FacebookResponseException $e) {
            $error = __('Graph returned an error: ','lrweb'). $e->getMessage();
            $message = array(
                'type' => 'error',
                'content' => $error
            );
        }
        // When validation fails or other local issues
        catch(FacebookSDKException $e) {
            $error = __('Facebook SDK returned an error: ','lrweb'). $e->getMessage();
            $message = array(
                'type' => 'error',
                'content' => $error
            );
        }

        // If we don't got a token, it means we had an error
        if (!isset($accessToken)) {
            // Report our errors
            $_SESSION['lr_facebook_message'] = $message;
            // Redirect
            header("Location: ".$this->redirect_url, true);
            die();
        }

        return $accessToken->getValue();

    }
	public function getUserDetails($fb)
    {

        try {
            $response = $fb->get('/me?fields=id,name,first_name,last_name,email,link', $this->access_token);
        } catch(FacebookResponseException $e) {
            $message = __('Graph returned an error: ','lrweb'). $e->getMessage();
            $message = array(
                'type' => 'error',
                'content' => $error
            );
        } catch(FacebookSDKException $e) {
            $message = __('Facebook SDK returned an error: ','lrweb'). $e->getMessage();
            $message = array(
                'type' => 'error',
                'content' => $error
            );
        }

        // If we caught an error
        if (isset($message)) {
            // Report our errors
            $_SESSION['lr_facebook_message'] = $message;
            // Redirect
            header("Location: ".$this->redirect_url, true);
            die();
        }

        return $response->getGraphUser();

    }
	public function loginUser() {

        // We look for the `eo_facebook_id` to see if there is any match
        $wp_users = get_users(array(
            'meta_key'     => 'lr_facebook_id',
            'meta_value'   => $this->facebook_details['id'],
            'number'       => 1,
            'count_total'  => false,
            'fields'       => 'id',
        ));

        if(empty($wp_users[0])) {
            return false;
        }

        // Log the user ?
        wp_set_auth_cookie( $wp_users[0] );

    }
	public function createUser() {


        $fb_user = $this->facebook_details;

        // Create an username
        $username = sanitize_user(str_replace(' ', '_', strtolower($this->facebook_details['name'])));

        // Creating our user
        $new_user = wp_create_user($username, wp_generate_password(), $fb_user['email']);

        if(is_wp_error($new_user)) {
            // Report our errors
            $_SESSION['lr_facebook_message'] = $new_user->get_error_message();
            // Redirect
            header("Location: ".$this->redirect_url, true);
            die();
        }

        // Setting the meta
        update_user_meta( $new_user, 'first_name', $fb_user['first_name'] );
        update_user_meta( $new_user, 'last_name', $fb_user['last_name'] );
        update_user_meta( $new_user, 'user_url', $fb_user['link'] );
        update_user_meta( $new_user, 'lr_facebook_id', $fb_user['id'] );

        // Log the user ?
        wp_set_auth_cookie( $new_user );

    }



}
new Wp_Ajax_Login_Shortcode();