<?php

function lr_login_register_modal() { 
?>

	<div class="modal fade pt-user-modal" id="pt-user-modal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" data-active-tab="">
		
			<div class="modal-content" style="background-color :#<?php $lr_general=get_option('lr_general'); echo $lr_general['form_background_color']; ?>">
			
			<?php 
				if( ! is_user_logged_in() ){ // only show the registration/login form to non-logged-in members ?>	
					<div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color :#<?php echo $lr_general['font_color_callback']; ?>">&times;</span></button>
						
						<!-- Register form -->
						<div class="pt-register">
							<?php $lr_signup=get_option('lr_signup');?>
							<div class="header_text">
							<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
							<?php if($lr_signup['signup_header_text'] ){ 
									echo $lr_signup['signup_header_text']; ?>
								<?php }else{ printf( __('Join %s', 'wp-ajax-login'), get_bloginfo('name') ); } ?>
							</h3>
							</div>
							<div class="logo">
								<?php $logo_image = $lr_general['logo_image']; ?>
								<img id='' src='<?php echo $logo_image; ?>'>
							</div>
							<hr>

							<?php if( $lr_signup ){ ?>
									
									<form id="pt_registration_form" action="<?php echo home_url( '/' ); ?>" method="POST">
									
									
									<?php if($lr_signup['signup_first_name'] ){ ?>
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('First Name', 'wp-ajax-login'); ?></span>
											<input class="form-control input-lg required" name="lr_first_name" type="text"  placeholder="<?php _e('First Name', 'wp-ajax-login'); ?>" required />
										</div>										
									<?php } ?>	
									
									<?php if($lr_signup['signup_last_name'] ){ ?>
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Last Name', 'wp-ajax-login'); ?></span>
											<input class="form-control input-lg required" name="lr_last_name" type="text" placeholder="<?php _e('Last Name', 'wp-ajax-login'); ?>" required />
										</div>
									<?php } ?>		
										
										
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Username', 'wp-ajax-login'); ?></span>
											<input class="form-control input-lg required" name="lr_user_login" type="text" placeholder="<?php _e('Username', 'wp-ajax-login'); ?>" />
										</div>
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Email', 'wp-ajax-login'); ?></span>
											<input class="form-control input-lg required" name="lr_user_email" id="pt_user_email" type="email" placeholder="<?php _e('Email', 'wp-ajax-login'); ?>" />
										</div>									
										
										
										<div class="form-field">
											<input type="hidden" name="action" value="lr_register_form"/>
											<?php $lr_general=get_option('lr_general');?>	
											<button class="btn btn-theme btn-lg" style="color :#<?php echo $lr_general['font_color_callback']; ?>" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
											<?php if($lr_signup['signup_button_text'] ){ ?>
											<?php echo $lr_signup['signup_button_text']; ?>
											<?php }else{ _e('Sign up', 'wp-ajax-login'); } ?></button>
										</div>
										<?php wp_nonce_field( 'ajax-login-nonce', 'register-form' ); ?>
									</form>
									<div class="pt-errors"></div>

							<?php } else {

								echo '<div class="alert alert-warning">'.__('Registration is disabled.', 'wp-ajax-login').'</div>';

							} ?>

							</div>

								<!-- Login form -->
								<div class="pt-login">
							
								<?php $lr_login=get_option('lr_login');?>								
								<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
								
								<?php $logo_image = $lr_general['logo_image'];
								if($logo_image !=''){
								?>
								<div class="logo">									
									<img id='' src='<?php echo $logo_image; ?>'>
								</div>
								<?php } ?>
								<?php if($lr_login['login_header_text'] ){ 
										echo $lr_login['login_header_text']; ?>
								<?php }else{ printf( __('Login to %s', 'wp-ajax-login'), get_bloginfo('name') ); } ?>
								
								</h3>
									<hr>
							 
									<form id="pt_login_form" action="<?php echo home_url( '/' ); ?>" method="post">
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Username', 'wp-ajax-login') ?></span>
											<input class="form-control input-lg required" name="lr_user_login" type="text" placeholder="<?php _e('Username', 'wp-ajax-login') ?>" />
										</div>
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Password', 'wp-ajax-login')?></span>
											<input class="form-control input-lg required" name="lr_user_pass" id="pt_user_pass" type="password"/ placeholder="<?php _e('Password', 'wp-ajax-login')?>">
										</div>
										<div class="form-field">
											<input type="hidden" name="action" value="lr_login_form"/>
											<button class="btn btn-theme btn-lg" style="color :#<?php echo $lr_general['font_color_callback']; ?>" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
											<?php if($lr_login['login_button_text'] ){ 
												echo $lr_login['login_button_text']; ?>
											<?php }else{ _e('Login', 'wp-ajax-login'); } ?>
											
											</button> <a class="alignright" href="#pt-reset-password" style="color:#<?php echo $lr_general['font_color_callback'];?>"><?php _e('Lost Password?', 'wp-ajax-login') ?></a>
										</div>
										<?php wp_nonce_field( 'ajax-login-nonce', 'login-form' ); ?>
									</form>
									<div class="pt-errors"></div>
								</div>
								
								<!-- Lost Password form -->
								<div class="pt-reset-password">
								<h3 style="color :#<?php echo $lr_general['font_color_callback']; ?>">
								<?php $lr_fpsw=get_option('lr_fpsw');?>
								<?php if($lr_fpsw['fpsw_header_text'] ){ 
										echo $lr_fpsw['fpsw_header_text']; ?>
								<?php }else {_e('Reset Password', 'wp-ajax-login'); } ?>
								</h3>
                                    <p style="color :#<?php echo $lr_general['font_color_callback']; ?>">
									<?php if($lr_fpsw['fpsw_header_detail_text'] ){ 
										echo $lr_fpsw['fpsw_header_detail_text']; ?>
									<?php }else {_e( 'Enter the username or e-mail you used in your profile. A password reset link will be sent to you by email.', 'wp-ajax-login'); } ?></p>
									<hr>
							 
									<form id="pt_reset_password_form" action="<?php echo home_url( '/' ); ?>" method="post">
										<div class="form-field">
											<span class="screen-reader-text"><?php _e('Username or E-mail', 'wp-ajax-login') ?></span>
											<input class="form-control input-lg required" name="lr_user_or_email" id="pt_user_or_email" type="text" placeholder="<?php _e('Username or E-mail', 'wp-ajax-login') ?>" />
										</div>
										<div class="form-field">
											<input type="hidden" name="action" value="lr_reset_password"/>
											<button class="btn btn-theme btn-lg" data-loading-text="<?php _e('Loading...', 'wp-ajax-login') ?>" type="submit">
											<?php if($lr_fpsw['fpsw_button_text'] ){ 
												echo $lr_fpsw['fpsw_button_text']; ?>
											<?php }else { _e('Get new password', 'wp-ajax-login'); } ?></button>
										</div>
										<?php wp_nonce_field( 'ajax-login-nonce', 'password-reset' ); ?>
									</form>
									<div class="pt-errors"></div>
								</div>

								<div class="pt-loading">
									<p><i class="fa fa-refresh fa-spin"></i><br><?php _e('Loading...', 'wp-ajax-login') ?></p>
								</div>
					</div>
					<div class="modal-footer">
					
						<a href ="<?php?>">FB</a>&nbsp;<a href ="<?php ?>">G+</a>
					
						<span class="pt-register-footer" style="color :#<?php echo $lr_general['font_color_callback']; ?>">
							<?php if($lr_login['login_footer_text'] ){ 
									echo $lr_login['login_footer_text']; ?>
							<?php }else{ _e('Don\'t have an account?', 'wp-ajax-login');}?>
							<a href="#pt-register" style="color:#<?php echo $lr_general['font_color_callback']; ?>"><?php _e('Sign Up', 'wp-ajax-login'); ?></a>
						</span>
							
						<span class="pt-login-footer" style="color :#<?php echo $lr_general['font_color_callback']; ?>">
							
							<?php if($lr_signup['signup_footer_text'] ){
									echo $lr_signup['signup_footer_text']; ?>
							<?php }else{ _e('Already have an account?', 'wp-ajax-login'); } ?> <a href="#pt-login" style="color:#<?php echo $lr_general['font_color_callback']; ?>"><?php _e('Login', 'wp-ajax-login'); ?></a>
						</span>
					</div>
				<?php } else { ?>
					<div class="modal-body">
						<div class="pt-logout">							
							<div class="alert alert-info"><?php $current_user = wp_get_current_user(); printf( __( 'You have already logged in as %1$s. <a href="#logout">Logout?</a>', 'wp-ajax-login' ), $current_user->user_login );?></div>
							<div class="pt-errors"></div>
						</div>
					</div>
				<?php } ?>		
				</div>
			</div>
		</div>
<?php }
add_action('wp_footer', 'lr_login_register_modal');

add_filter( 'wp_nav_menu_items', 'lr_login_link_to_menu', 10, 2 );
function lr_login_link_to_menu ( $items, $args ) {
    if( $args->theme_location == apply_filters('login_menu_location', 'primary') ) {

    	if ( ! is_user_logged_in() ) {
    		$text = __( 'Login/Register', 'wp-ajax-login' );
    	} else {
    		$text = __( 'Logout?', 'wp-ajax-login' );
    	}
        	$items .= '<li class="menu-item login-link"><a href="#pt-login">'.$text.'</a></li>';

    }
    return $items;
}

function lr_shortcode( $atts ) {

	$atts = shortcode_atts( array(
		'text' => 'Login/Register',
	), $atts, 'wp-ajax-login' );

	return "<a href='#pt-login'>{$atts['text']}</a>";
}
add_shortcode( 'wp-ajax-login', 'lr_shortcode' );