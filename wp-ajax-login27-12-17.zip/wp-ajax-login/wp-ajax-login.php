<?php
/**
 * Plugin Name:       WP AJAX Login and Register Popup Form
 * Plugin URI:        http://logicrays.com
 * Description:       Easy to use frontend AJAX Login and Register plugin
 * Version:           1.0
 * Author:            logicrays
 * Author URI:        http://logicrays.com
 * Text Domain:       wp-ajax-login
 * Domain Path:       /languages
 */
 
if ( ! defined( 'WPINC' ) ) {
	die;
}
function activate_wp_ajax_login_plugin(){
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-ajax-login-plugin-activate.php';
	Wp_Ajax_Login_Plugin_Activate::activate();
}
function deactivate_wp_ajax_login_plugin(){
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-ajax-login-plugin-deactivate.php';
	Wp_Ajax_Login_Plugin_Deactivate::deactivate();
}
register_activation_hook( __FILE__, 'activate_wp_ajax_login_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_wp_ajax_login_plugin' );

require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-ajax-login.php';

function run_wp_ajax_login() {
	
	$plugin = new Wp_Ajax_Login();
	$plugin->run();

}
run_wp_ajax_login();