<?php
class Wp_Ajax_Login_Admin_Action {

	private $plugin_name;
	private $version;
	private $options_general;
    private $options_login;
    private $options_signup;
	private $options_fpsw;
	private $options_social_login;
	
	public function __construct( $plugin_name, $version ) {
	
		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'lr_options_init' ) );
		add_action('admin_enqueue_scripts', array( $this, 'load_wp_media_files'));		
	}
	function load_wp_media_files(){
		wp_enqueue_media();
	}
	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cs-wp-color-picker.min.css', array(), $this->version, 'all' );
	}
	
	public function enqueue_scripts() {		
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/jscolor.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script('rbr-jquery', plugin_dir_url( __FILE__ ) . 'js/admin_js.js', array('jquery'), '1.0', true);
	}
	public function add_plugin_page(){
    	add_menu_page('Wp Ajax Login Setting Tab', 'Wp Ajax Login Setting Tab', 'manage_options', 'wp-ajax-login' , array( $this,'lr_admin_lrcodes') );
    }
	
	public function lr_admin_lrcodes() {
        $this->options_general = get_option( 'lr_general' );
		$this->options_login = get_option( 'lr_login' );
		$this->options_signup = get_option( 'lr_signup' ); 
		$this->options_fpsw = get_option( 'lr_fpsw' ); 
		$this->options_social_login = get_option( 'lr_social_login' ); 
		$login_Screen = ( isset( $_GET['action'] ) && 'login' == $_GET['action'] ) ? true : false;
		$signup_Screen = ( isset( $_GET['action'] ) && 'signup' == $_GET['action'] ) ? true : false;    
		$fpsw_Screen = ( isset( $_GET['action'] ) && 'fpsw' == $_GET['action'] ) ? true : false;  
		$social_login_Screen = ( isset( $_GET['action'] ) && 'social_login' == $_GET['action'] ) ? true : false		
	?>
		<?php if( isset($_GET['settings-updated']) ) { ?>
		<div id="message" class="updated">
		<p><strong>Settings saved</strong></p>
		<?php } ?>
		</div>
        <div class="wrap">
            <h1>Wp Ajax Login Setting Tab Settings</h1>
            <h2 class="nav-tab-wrapper">
				<a href="<?php echo admin_url( 'admin.php?page=wp-ajax-login' ); ?>" class="nav-tab<?php if ( ! isset( $_GET['action'] ) || isset( $_GET['action'] ) && 'login' != $_GET['action']  && 'signup' != $_GET['action'] && 'fpsw' != $_GET['action'] && 'social_login' != $_GET['action']) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'General' ); ?></a>	
				<a href="<?php echo esc_url( add_query_arg( array( 'action' => 'login' ), admin_url( 'admin.php?page=wp-ajax-login' ) ) ); ?>" class="nav-tab<?php if ( $login_Screen ) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'login' ); ?></a> 
				<a href="<?php echo esc_url( add_query_arg( array( 'action' => 'signup' ), admin_url( 'admin.php?page=wp-ajax-login' ) ) ); ?>" class="nav-tab<?php if ( $signup_Screen ) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'signup' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( array( 'action' => 'fpsw' ), admin_url( 'admin.php?page=wp-ajax-login' ) ) ); ?>" class="nav-tab<?php if ( $fpsw_Screen ) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'Forget Password' ); ?></a>
				<a href="<?php echo esc_url( add_query_arg( array( 'action' => 'social_login' ), admin_url( 'admin.php?page=wp-ajax-login' ) ) ); ?>" class="nav-tab<?php if ( $social_login_Screen ) echo ' nav-tab-active'; ?>"><?php esc_html_e( 'Social Login' ); ?></a>
			
			</h2>
    
        	 <form method="post" action="options.php"><?php //   settings_fields( 'lr_general' );
				 if($login_Screen) { 
					settings_fields( 'lr_login' );
					do_settings_sections( 'lr-setting-login' );
					submit_button();
				} elseif($signup_Screen) {
					settings_fields( 'lr_signup' );
					do_settings_sections( 'lr-setting-signup' );
					submit_button();
				} elseif($fpsw_Screen) {
					settings_fields( 'lr_fpsw' );
					do_settings_sections( 'lr-setting-fpsw' );
					submit_button();
				} elseif($social_login_Screen) {
					settings_fields( 'lr_social_login' );
					do_settings_sections( 'lr-setting-social-login' );
					submit_button();
				} else { 
					settings_fields( 'lr_general' );
					do_settings_sections( 'lr-setting-admin' );
					submit_button();
				} ?>
			</form>
        </div> <?php
	}
	public function lr_options_init() { 
	
	/*==================== General Tab =================================*/
	
        register_setting(
            'lr_general', // Option group
            'lr_general', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', // ID
            'All Settings', // Title
            array( $this, 'print_section_info' ), // Callback
            'lr-setting-admin' // Page
        ); 
		add_settings_field(
            'logo_image', 
            'Logo Image', 
            array( $this, 'logo_image_callback' ), 
            'lr-setting-admin', 
            'setting_section_id'
        ); 
			
		add_settings_field(
            'form_background_color', 
            'Form Background Color', 
            array( $this, 'form_background_color_callback' ), 
            'lr-setting-admin', 
            'setting_section_id'
        );  
		add_settings_field(
            'font_color', 
            'Form Color', 
            array( $this, 'font_color_callback' ), 
            'lr-setting-admin', 
            'setting_section_id'
        );  
		add_settings_field(
            'form_shortcode', 
            'Form Shortcode', 
            array( $this, 'form_shortcode_callback' ), 
            'lr-setting-admin', 
            'setting_section_id'
        );  
	
	/*==================== Login Tab =================================*/	
		register_setting(
            'lr_login', // Option group
            'lr_login', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );
        add_settings_section(
            'setting_section_id', // ID
            'login Settings', // Title
            array( $this, 'print_section_info' ), // Callback
            'lr-setting-login' // Page
        );  
		
		add_settings_field(
            'login_header_text', // ID
            'Login Form Header Text', // Title 
            array( $this, 'login_header_text_callback' ), // Callback
            'lr-setting-login', // Page
            'setting_section_id' // Section           
        );
		add_settings_field(
            'login_footer_text', // ID
            'Login Form Footer Text', // Title 
            array( $this, 'login_footer_text_callback' ), // Callback
            'lr-setting-login', // Page
            'setting_section_id' // Section           
        );
		add_settings_field(
            'login_button_text', // ID
            'Login Form Button Text', // Title 
            array( $this, 'login_button_text_callback' ), // Callback
            'lr-setting-login', // Page
            'setting_section_id' // Section           
        );

	/*==================== Signup Tab =================================*/	
		
		register_setting(
            'lr_signup', // Option group
            'lr_signup', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );
        add_settings_section(
            'setting_section_id', // ID
            'signup Details', // Title
            array( $this, 'print_section_info' ), // Callback
            'lr-setting-signup' // Page
        ); 
        		
		add_settings_field(
            'signup_first_name', 
            'First Name', 
            array( $this, 'signup_first_name_text_callback' ), 
            'lr-setting-signup', 
            'setting_section_id'
        );
		add_settings_field(
            'signup_last_name', 
            'Last Name', 
            array( $this, 'signup_last_name_text_callback' ), 
            'lr-setting-signup', 
            'setting_section_id'
        );		
		
        add_settings_field(
            'signup_header_text', 
            'Signup Form Header Text', 
            array( $this, 'signup_header_text_callback' ), 
            'lr-setting-signup', 
            'setting_section_id'
        );
		add_settings_field(
            'signup_footer_text', 
            'Signup Form Footer Text', 
            array( $this, 'signup_footer_text_callback' ), 
            'lr-setting-signup', 
            'setting_section_id'
        );
		add_settings_field(
            'signup_button_text', 
            'Signup Form Button Text', 
            array( $this, 'signup_button_text_callback' ), 
            'lr-setting-signup', 
            'setting_section_id'
        );
		
	/*=============== Forget Password Tab =========================*/
	
		register_setting(
			'lr_fpsw', // Option group
			'lr_fpsw', // Option name
			array( $this, 'sanitize' ) // Sanitize
		);
		add_settings_section(
			'setting_section_id', // ID
			'Forget Password Details', // Title
			array( $this, 'print_section_info' ), // Callback
			'lr-setting-fpsw' // Page
		); 
		add_settings_field(
            'fpsw_header_text', 
            'Forget Password Header Text', 
            array( $this, 'fpsw_header_text_callback' ), 
            'lr-setting-fpsw', 
            'setting_section_id'
        ); 
		add_settings_field(
            'fpsw_header_detail_text', 
            'Forget Password Header Details Text', 
            array( $this, 'fpsw_header_detail_text_callback' ), 
            'lr-setting-fpsw', 
            'setting_section_id'
        ); 
		add_settings_field(
            'fpsw_button_text', 
            'Forget Password Button Text', 
            array( $this, 'fpsw_button_text_callback' ), 
            'lr-setting-fpsw', 
            'setting_section_id'
        ); 
		
		/*=============== Social Login Tab ========================= */
	
		register_setting(
			'lr_social_login', // Option group
			'lr_social_login', // Option name
			array( $this, 'sanitize' ) // Sanitize
		);
		add_settings_section(
			'setting_section_id', // ID
			'Social Login Details', // Title
			array( $this, 'print_section_info' ), // Callback
			'lr-setting-social-login' // Page
		); 
		add_settings_field(
            'gmail_login_image', 
            'Gmail Login Image', 
            array( $this, 'gmail_login_image_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        ); 
		add_settings_field(
            'enable_gmail', 
            'Gmail', 
            array( $this, 'enable_gmail_login_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		add_settings_field(
            'gmail_applcation_id', 
            'Application ID', 
            array( $this, 'gmail_applcation_id_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		add_settings_field(
            'gmail_applcation_secret', 
            'Application Secret', 
            array( $this, 'gmail_applcation_secret_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		
		
		add_settings_field(
            'fb_login_image', 
            'Facebook Login Image', 
            array( $this, 'fb_login_image_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        ); 
		add_settings_field(
            'enable_fb', 
            'Facebook', 
            array( $this, 'enable_fb_login_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		add_settings_field(
            'fb_applcation_id', 
            'Application ID', 
            array( $this, 'fb_applcation_id_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		add_settings_field(
            'fb_applcation_secret', 
            'Application Secret', 
            array( $this, 'fb_applcation_secret_callback' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		add_settings_field(
            'fb_callback_url', 
            'Facebook Callback Url', 
            array( $this, 'fb_applcation_callback_url' ), 
            'lr-setting-social-login', 
            'setting_section_id'
        );
		
		
		
	}
	
		
	public function print_section_info(){
			//your code...
	}
	
	/*========================== Social Login Tab Fucntion =============================*/
	public function gmail_login_image_callback() {
	
	
    }
	public function enable_gmail_login_callback() {
		printf(
			'<input type="checkbox" class="regular-text" id="enable_gmail" name="lr_social_login[enable_gmail]" value="yes" %s />',
			(isset( $this->options_social_login['enable_gmail'] ) && $this->options_social_login['enable_gmail'] == 'yes') ? 'checked' : ''
		);
	}
	public function gmail_applcation_id_callback() {
       printf(
            '<input type="text" class="regular-text" id="gmail_applcation_id" name="lr_social_login[gmail_applcation_id]" value="%s" />',
            isset( $this->options_social_login['gmail_applcation_id'] ) ? esc_attr( $this->options_social_login['gmail_applcation_id']) : ''
        );
    }
	public function gmail_applcation_secret_callback() {
       printf(
            '<input type="text" class="regular-text" id="gmail_applcation_secret" name="lr_social_login[gmail_applcation_secret]" value="%s" />',
            isset( $this->options_social_login['gmail_applcation_secret'] ) ? esc_attr( $this->options_social_login['gmail_applcation_secret']) : ''
        );
    }
	
	
	public function fb_login_image_callback() {
	
    }
	public function enable_fb_login_callback() {
		printf(
			'<input type="checkbox" class="regular-text" id="enable_fb" name="lr_social_login[enable_fb]" value="yes" %s />',
			(isset( $this->options_social_login['enable_fb'] ) && $this->options_social_login['enable_fb'] == 'yes') ? 'checked' : ''
		);
	}
	public function fb_applcation_id_callback() {
       printf(
            '<input type="text" class="regular-text" id="gmail_applcation_id" name="lr_social_login[fb_applcation_id]" value="%s" />',
            isset( $this->options_social_login['fb_applcation_id'] ) ? esc_attr( $this->options_social_login['fb_applcation_id']) : ''
        );
    }
	public function fb_applcation_secret_callback() {
       printf(
            '<input type="text" class="regular-text" id="gmail_applcation_secret" name="lr_social_login[fb_applcation_secret]" value="%s" />',
            isset( $this->options_social_login['fb_applcation_secret'] ) ? esc_attr( $this->options_social_login['fb_applcation_secret']) : ''
        );
    }
	public function fb_applcation_callback_url() {
       printf(
            '<input type="text" class="regular-text" id="gmail_applcation_secret" name="lr_social_login[fb_callback_url]" value="%s" />',
            isset( $this->options_social_login['fb_callback_url'] ) ? esc_attr( $this->options_social_login['fb_callback_url']) : ''
        );
    }
	/*==================== Forget Password Tab Fucntion =================================*/
	public function fpsw_header_text_callback() {
       printf(
            '<input type="text" class="regular-text" id="fpsw_header_text" name="lr_fpsw[fpsw_header_text]" value="%s" />',
            isset( $this->options_fpsw['fpsw_header_text'] ) ? esc_attr( $this->options_fpsw['fpsw_header_text']) : ''
        );
    }
	public function fpsw_header_detail_text_callback() {
      printf(
            '<input type="text" class="regular-text" id="fpsw_header_detail_text" name="lr_fpsw[fpsw_header_detail_text]" value="%s" />',
            isset( $this->options_fpsw['fpsw_header_detail_text'] ) ? esc_attr( $this->options_fpsw['fpsw_header_detail_text']) : ''
        );
    }
	public function fpsw_button_text_callback() {
      printf(
            '<input type="text" class="regular-text" id="fpsw_button_text" name="lr_fpsw[fpsw_button_text]" value="%s" />',
            isset( $this->options_fpsw['fpsw_button_text'] ) ? esc_attr( $this->options_fpsw['fpsw_button_text']) : ''
        );
    }
	/*==================== Login Tab Fucntion =================================*/
	public function login_header_text_callback() {
        printf(
            '<input type="text" class="regular-text" id="login_header_text" name="lr_login[login_header_text]" value="%s" />',
            isset( $this->options_login['login_header_text'] ) ? esc_attr( $this->options_login['login_header_text']) : ''
        );
    }
	public function login_footer_text_callback() {
        printf(
            '<input type="text" class="regular-text" id="login_footer_text" name="lr_login[login_footer_text]" value="%s" />',
            isset( $this->options_login['login_footer_text'] ) ? esc_attr( $this->options_login['login_footer_text']) : ''
        );
    }
	public function login_button_text_callback() {
        printf(
            '<input type="text" class="regular-text" id="login_button_text" name="lr_login[login_button_text]" value="%s" />',
            isset( $this->options_login['login_button_text'] ) ? esc_attr( $this->options_login['login_button_text']) : ''
        );
    }
	
	/*==================== Signup Tab Fucntion =================================*/
	public function signup_first_name_text_callback(){       
		printf(
			'<input type="checkbox" class="regular-text" id="signup_first_name" name="lr_signup[signup_first_name]" value="yes" %s />',
			(isset( $this->options_signup['signup_first_name'] ) && $this->options_signup['signup_first_name'] == 'yes') ? 'checked' : ''
		);
    }
	public function signup_last_name_text_callback(){        
		printf(
			'<input type="checkbox"class="regular-text"  id="signup_last_name" name="lr_signup[signup_last_name]" value="yes" %s />',
			(isset( $this->options_signup['signup_last_name'] ) && $this->options_signup['signup_last_name'] == 'yes') ? 'checked' : ''
		);
    }
    public function signup_header_text_callback(){
        printf(
            '<input type="text" class="regular-text" id="signup_header_text" name="lr_signup[signup_header_text]" value="%s" />',
            isset( $this->options_signup['signup_header_text'] ) ? esc_attr( $this->options_signup['signup_header_text']) : ''
        );
    }
	public function signup_footer_text_callback(){
        printf(
            '<input type="text" class="regular-text" id="signup_footer_text" name="lr_signup[signup_footer_text]" value="%s" />',
            isset( $this->options_signup['signup_footer_text'] ) ? esc_attr( $this->options_signup['signup_footer_text']) : ''
        );
    }
	public function signup_button_text_callback(){
        printf(
            '<input type="text" class="regular-text" id="signup_button_text" name="lr_signup[signup_button_text]" value="%s" />',
            isset( $this->options_signup['signup_button_text'] ) ? esc_attr( $this->options_signup['signup_button_text']) : ''
        );
    }
	/*==================== General Tab Fucntion =================================*/
    public function logo_image_callback() {
	if ( isset( $_POST['submit_image_selector'] ) && isset( $_POST['image_attachment_id'] ) ) :
		update_option( 'media_selector_attachment_id', absint( $_POST['image_attachment_id'] ) );
	endif;
	wp_enqueue_media();	
	?>
	<?php $lr_general=get_option('lr_general');
	$logo_image = $lr_general['logo_image'];
	
	?>
	
	<form method='post'>
		<div class='image-preview-wrapper'>
			<img id='image-preview' src='<?php echo $logo_image; ?>' height='100'>
			<?php if($logo_image !=''){ ?>
			<a class="remove-image">Remove</a>
			<?php } ?>
		</div>		
	</form>
	
	<?php
        printf(
            '<input type="text" name="lr_general[logo_image]" class="regular-text" id="logo_image" value="%s"> 
			<a href="#" id="logo_image_url" class="button" > Select </a>',
            isset( $this->options_general['logo_image'] ) ? esc_attr( $this->options_general['logo_image']) : ''
             );
    }
	
	public function form_background_color_callback () {
		
		printf(
            '<input type="text" id="form_background_color" class="jscolor regular-text" placeholder="Color code here" name="lr_general[form_background_color]" value="%s" />',
            isset( $this->options_general['form_background_color'] ) ? esc_attr( $this->options_general['form_background_color']) : ''
        );
	}
	public function font_color_callback () {
		
		printf(
            '<input type="text" class="jscolor regular-text" id="font_color_callback" placeholder="Color code here" name="lr_general[font_color_callback]" value="%s" />',
            isset( $this->options_general['font_color_callback'] ) ? esc_attr( $this->options_general['font_color_callback']) : ''
        );
	}
	public function form_shortcode_callback () {
	
		printf(
            '<input type="text" class="regular-text" id="form_shortcode_callback" name="lr_general[form_shortcode_callback]" value="[wp-ajax-login text=Login/Register]" readonly/>',
            isset( $this->options_general['form_shortcode_callback'] ) ? esc_attr( $this->options_general['form_shortcode_callback']) : ''
        );
	}
	public function sanitize( $input )  {
        $new_input = array();
		/* Login */
        if( isset( $input['login_header_text'] ) )
            $new_input['login_header_text'] = sanitize_text_field( $input['login_header_text'] );
		if( isset( $input['login_footer_text'] ) )
            $new_input['login_footer_text'] = sanitize_text_field( $input['login_footer_text'] );
		if( isset( $input['login_button_text'] ) )
            $new_input['login_button_text'] = sanitize_text_field( $input['login_button_text'] );
      
	  
	  /* Signup */
		if( isset( $input['signup_first_name'] ) )
            $new_input['signup_first_name'] = sanitize_text_field( $input['signup_first_name'] );
		if( isset( $input['signup_last_name'] ) )
            $new_input['signup_last_name'] = sanitize_text_field( $input['signup_last_name'] );
        if( isset( $input['signup_header_text'] ) )
            $new_input['signup_header_text'] = sanitize_text_field( $input['signup_header_text'] );
		if( isset( $input['signup_footer_text'] ) )
            $new_input['signup_footer_text'] = sanitize_text_field( $input['signup_footer_text'] );
		if( isset( $input['signup_button_text'] ) )
            $new_input['signup_button_text'] = sanitize_text_field( $input['signup_button_text'] );
       
	   
	   /* General */
        if( isset( $input['logo_image'] ) )
            $new_input['logo_image'] = sanitize_text_field( $input['logo_image'] );
		if( isset( $input['form_background_color'] ) )
            $new_input['form_background_color'] = sanitize_text_field( $input['form_background_color'] );
		if( isset( $input['font_color_callback'] ) )
            $new_input['font_color_callback'] = sanitize_text_field( $input['font_color_callback'] );
		
		/* Footer Password */
        if( isset( $input['fpsw_header_text'] ) )
            $new_input['fpsw_header_text'] = sanitize_text_field( $input['fpsw_header_text'] );
		if( isset( $input['fpsw_header_detail_text'] ) )
            $new_input['fpsw_header_detail_text'] = sanitize_text_field( $input['fpsw_header_detail_text'] );
		if( isset( $input['fpsw_button_text'] ) )
            $new_input['fpsw_button_text'] = sanitize_text_field( $input['fpsw_button_text'] );
			
		/* Social Login */
        if( isset( $input['gmail_login_image'] ) )
            $new_input['gmail_login_image'] = sanitize_text_field( $input['gmail_login_image'] );
		if( isset( $input['enable_gmail'] ) )
            $new_input['enable_gmail'] = sanitize_text_field( $input['enable_gmail'] );
		if( isset( $input['gmail_applcation_id'] ) )
            $new_input['gmail_applcation_id'] = sanitize_text_field( $input['gmail_applcation_id'] );
		if( isset( $input['gmail_applcation_secret'] ) )
            $new_input['gmail_applcation_secret'] = sanitize_text_field( $input['gmail_applcation_secret'] );
		
		if( isset( $input['fb_login_image'] ) )
            $new_input['fb_login_image'] = sanitize_text_field( $input['fb_login_image'] );		
		if( isset( $input['enable_fb'] ) )
            $new_input['enable_fb'] = sanitize_text_field( $input['enable_fb'] );
		if( isset( $input['fb_applcation_id'] ) )
            $new_input['fb_applcation_id'] = sanitize_text_field( $input['fb_applcation_id'] );
		if( isset( $input['fb_applcation_secret'] ) )
            $new_input['fb_applcation_secret'] = sanitize_text_field( $input['fb_applcation_secret'] );
		if( isset( $input['fb_callback_url'] ) )
            $new_input['fb_callback_url'] = sanitize_text_field( $input['fb_callback_url'] );
			
			
        return $new_input;
    }
}
