<?php


class Wp_Ajax_Login {

	protected $loader;
	protected $plugin_name;
	protected $version;
	
	public function __construct() {
	
		$this->plugin_name = 'wp-ajax-login';
		$this->version = '1.2';
		$this->load_required_file();
		$this->set_multi_language();
		$this->set_adminside_action();
		$this->set_frontside_action();
	}
	
	private function load_required_file() {
	
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp-action-hook.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp-multi-language.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wp-ajax-login-admin-action.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'front/class-wp-ajax-login-front-action.php';
		//require_once plugin_dir_path( dirname( __FILE__ ) ) . 'front/shortcode/wp-ajax-login-shortcode.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'front/shortcode/class-wp-ajax-login-shortcode.php';
		$this->loader = new Wp_Action_Hook();		
	
	}
	
	private function set_multi_language() {
	
		$plugin_ml = new Wp_Multi_Language();
		$this->loader->add_action( 'plugins_loaded', $plugin_ml, 'load_plugin_textdomain' );
	
	}
	
	private function set_adminside_action() {
		
		$admin_action = new Wp_Ajax_Login_Admin_Action( $this->get_plugin_name(), $this->get_version() );		
		$this->loader->add_action( 'admin_enqueue_scripts', $admin_action, 'enqueue_scripts' );
	}
	
	private function set_frontside_action() {
		
		$front_action = new Wp_Ajax_Login_Front_Action( $this->get_plugin_name(), $this->get_version() );
		$this->loader->add_action( 'wp_enqueue_scripts', $front_action, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $front_action, 'enqueue_scripts' );
		$this->loader->add_action( 'wp_ajax_nopriv_lr_login_form', $front_action, 'lr_login_form' );
		$this->loader->add_action( 'wp_ajax_nopriv_lr_register_form', $front_action, 'lr_register_form' );
		$this->loader->add_action( 'wp_ajax_nopriv_lr_reset_password', $front_action, 'lr_reset_password' );
		$this->loader->add_action( 'wp_ajax_lr_logout', $front_action, 'lr_logout' );
	
	}
	
	public function run() {
		$this->loader->run();
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_loader() {
		return $this->loader;
	}

	public function get_version() {
		return $this->version;
	}
	
}