<?php
class Wp_Ajax_Login_Plugin_Deactivate{
	public static function deactivate() {

	}
}