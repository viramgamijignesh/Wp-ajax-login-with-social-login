<?php
class Wp_Multi_Language {

	public function load_plugin_textdomain() {
		load_plugin_textdomain(
			'wp-ajax-login',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}
}
