<?php
class Wp_Ajax_Login_Plugin_Activate{
	public static function activate() {

	}
}